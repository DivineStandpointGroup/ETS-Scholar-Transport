# ETS Scholar Transport — App Monorepo

Two connected mobile apps for Elisheva Transport Services (ETS), sharing one
Supabase backend:

- **`apps/driver`** — the driver app. Sign in, start a route, and the phone
  reports live GPS in the background. (Driving-behaviour telemetry is
  modeled in the schema but not yet captured — that's Phase 3.)
- **`apps/tracking`** — the parent / school / ETS-ops app. Sign in and see
  whichever routes your role can see, live on a map.
- **`packages/shared`** — TypeScript types matching the database schema,
  plus the one function both apps use to create their Supabase client.
- **`supabase/migrations/0001_init.sql`** — the full Phase 0 data model
  (schools, vehicles, drivers, parents, scholars, routes, trips, live
  location, driving events, driver scores) with Row Level Security
  policies enforcing who can see what.

This is Phase 0 of the plan in `App/ETS-App-Technical-Plan.md` — a working
scaffold, not a finished product. See **Current status** below for exactly
what does and doesn't work yet.

## Decisions locked in for this build

- **Internal pilot first.** No public app-store release yet — this is built
  to be installed directly on ETS's own driver phones and a handful of
  parent phones via Expo (see "Running the apps" below). Apple/Google
  developer accounts aren't needed until you're ready for a store release.
- **Backend: Supabase.** Managed Postgres + Realtime + Auth, generous free
  tier. Comfortably covers ETS's current scale (2 vehicles, ~11 scholars
  across schools, scaling up at Pecanwood).
- **Maps: Google Maps** via `react-native-maps`.

## One-time setup

### 1. Create the Supabase project

1. Go to [supabase.com](https://supabase.com), create a free account and a
   new project (pick a region close to South Africa, e.g. one of the
   European regions — Supabase has no African region yet).
2. In the SQL Editor, run `supabase/migrations/0001_init.sql` once. That
   creates every table, the roles, and the Row Level Security policies.
3. Optionally run `supabase/seed.sql` for sample test data — read the
   comments in that file first, it needs real Supabase Auth user ids
   plugged in before the profile rows will work.
4. In Project Settings → API, copy the **Project URL** and the **anon
   public key**. You'll need both in step 3 below.
5. In Authentication → Providers, email/password sign-in is on by default —
   that's what both apps use to log drivers/parents/school admins/ops in.
   Create your first few test users under Authentication → Users, then give
   each one a matching row in `profiles` (and `drivers`/`parents` as
   appropriate) via the Table Editor or SQL Editor.

### 2. Get a Google Maps API key (for the tracking app)

You need a Maps SDK for Android key and a Maps SDK for iOS key from the
[Google Cloud Console](https://console.cloud.google.com/) (enable "Maps SDK
for Android" and "Maps SDK for iOS" on the same API key, or use two keys).
Google gives a monthly free credit that easily covers a pilot at ETS's
current scale.

### 3. Environment variables

Each app reads its Supabase credentials from a `.env` file (not committed —
see `.gitignore`):

```
cd apps/driver && cp .env.example .env   # then fill in the two values
cd apps/tracking && cp .env.example .env # same here
```

For the tracking app's Google Maps keys, replace the placeholder strings
`GOOGLE_MAPS_ANDROID_API_KEY` / `GOOGLE_MAPS_IOS_API_KEY` in
`apps/tracking/app.json` directly (Expo's static `app.json` can't read
`.env` for native config the way it can for JS code) — **don't commit real
keys to git; restrict them to your app's package name / bundle id in the
Google Cloud Console instead.**

### 4. Install dependencies

From the repo root (this installs all three workspaces at once):

```
npm install
```

## Running the apps

Each app runs independently with [Expo Go](https://expo.dev/go) during
development — install Expo Go on a phone, then:

```
npm run driver     # starts the driver app, scan the QR code in Expo Go
npm run tracking    # starts the tracking app, scan the QR code in Expo Go
```

Background location on the driver app requires a real device (Expo Go's
background location support is limited) — test that part on an actual
Android or iOS phone, not a simulator.

For the internal pilot, once you're past basic testing, an **Expo
development build** or **internal distribution build** (via `eas build`)
is the way to get the apps onto driver/parent phones without going through
the App Store or Play Store review process. That's a Phase 5 concern, not
needed yet.

## Repo layout

```
ets-scholar-transport/
├── apps/
│   ├── driver/           Expo app — drivers
│   └── tracking/         Expo app — parents / school / ops
├── packages/
│   └── shared/           Shared TS types + Supabase client factory
├── supabase/
│   ├── migrations/0001_init.sql   Full Phase 0 schema + RLS
│   └── seed.sql                    Optional sample data for local testing
└── README.md              You are here
```

## Current status (Phase 0)

**Done:**
- Full data model + RLS policies for the four roles (driver, parent,
  school, ops).
- Driver app: email/password login, shows the driver's assigned route,
  Start Route / End Route, background GPS reporting into `location_pings`
  while a route is active (`expo-location` + `expo-task-manager`).
- Tracking app: email/password login, role-aware list of visible routes,
  a map screen that shows the route's stops and the vehicle's last known
  position, live-updating via Supabase Realtime while on route.
- Both apps typecheck cleanly (`npm run typecheck` at the repo root).

**Not done yet — later phases per the technical plan:**
- Driver performance scoring (Phase 3) — the `driving_events` and
  `driver_scores` tables exist in the schema, but nothing writes to them
  yet. That's the next meaningful chunk of work after Phase 1/2 are
  proven out with real drivers.
- ETS ops dashboard (Phase 4) — fleet-wide view, scorecards, trip history.
  The tracking app currently shows the same route-list-then-map flow to
  every role; ops will want a richer view once there's more than one
  active vehicle to watch at a time.
- Notifications, deeper role/permissions polish, and pilot testing with
  real drivers and parent families (Phase 5).
- No GitHub remote has been created yet — this folder is a plain local git
  repo (`git log` to see the initial commit). Push it to a GitHub repo
  under your account when you're ready; from the ETS Scholar Transport
  OneDrive folder, `git remote add origin <your-repo-url>` then
  `git push -u origin main`.

## A note on dependency versions

`package.json` at the repo root pins two versions via `overrides`:

- `typescript: ~5.6.3` — Expo's template defaults to a newer TypeScript
  release; pinning to 5.6.3 avoids inference issues seen with the schema
  types below during scaffolding.
- `@supabase/supabase-js: 2.45.4` — a newer minor version's generated
  types had a bug that broke `.insert()`/`.update()` type-checking against
  a hand-written `Database` type like the one in `packages/shared`. 2.45.4
  is the version this scaffold was built and verified against. Worth
  revisiting both pins occasionally as the ecosystem moves on — just run
  `npm run typecheck` after bumping either one to confirm nothing broke.
