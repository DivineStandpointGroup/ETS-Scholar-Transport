import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import type { LocationPing, Route, RouteStop, Trip } from '@ets/shared';
import { supabase } from '../lib/supabase';

interface Props {
  route: Route;
  onBack: () => void;
}

export default function MapScreen({ route, onBack }: Props) {
  const [trip, setTrip] = useState<Trip | null>(null);
  const [stops, setStops] = useState<RouteStop[]>([]);
  const [lastPing, setLastPing] = useState<LocationPing | null>(null);
  const [loading, setLoading] = useState(true);

  // Load the active trip and the route's stops once.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [{ data: tripRow }, { data: stopRows }] = await Promise.all([
        supabase
          .from('trips')
          .select('*')
          .eq('route_id', route.id)
          .eq('status', 'in_progress')
          .maybeSingle(),
        supabase.from('route_stops').select('*').eq('route_id', route.id).order('sequence'),
      ]);
      if (cancelled) return;
      setTrip(tripRow ?? null);
      setStops(stopRows ?? []);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [route.id]);

  // Once we know the trip, fetch its most recent ping and then subscribe to
  // new ones over Realtime so the marker moves live.
  useEffect(() => {
    if (!trip) return;

    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from('location_pings')
        .select('*')
        .eq('trip_id', trip.id)
        .order('recorded_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (!cancelled && data) setLastPing(data);
    })();

    const channel = supabase
      .channel(`trip-${trip.id}-pings`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'location_pings', filter: `trip_id=eq.${trip.id}` },
        (payload) => setLastPing(payload.new as LocationPing),
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [trip]);

  const initialRegion = useMemo(() => {
    const first = stops[0];
    return {
      latitude: first?.latitude ?? -25.7479, // Pretoria, as a sane fallback
      longitude: first?.longitude ?? 28.2293,
      latitudeDelta: 0.05,
      longitudeDelta: 0.05,
    };
  }, [stops]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Text style={styles.back}>{'‹ Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>{route.name}</Text>
        <View style={{ width: 44 }} />
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator />
        </View>
      ) : !trip ? (
        <View style={styles.center}>
          <Text style={styles.empty}>This route isn't on the road right now.</Text>
        </View>
      ) : (
        <MapView
          style={styles.map}
          provider={PROVIDER_GOOGLE}
          initialRegion={initialRegion}
        >
          {stops.length > 1 && (
            <Polyline
              coordinates={stops.map((s) => ({ latitude: s.latitude, longitude: s.longitude }))}
              strokeWidth={3}
              strokeColor="#1d4ed8"
            />
          )}
          {stops.map((s) => (
            <Marker
              key={s.id}
              coordinate={{ latitude: s.latitude, longitude: s.longitude }}
              title={s.label}
              pinColor="#94a3b8"
            />
          ))}
          {lastPing && (
            <Marker
              coordinate={{ latitude: lastPing.latitude, longitude: lastPing.longitude }}
              title="Vehicle"
              description={`Last update: ${new Date(lastPing.recorded_at).toLocaleTimeString()}`}
              pinColor="#16a34a"
            />
          )}
        </MapView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingTop: 40,
  },
  back: { color: '#1d4ed8', fontSize: 16, width: 44 },
  title: { fontSize: 17, fontWeight: '700' },
  map: { flex: 1 },
  empty: { color: '#888', paddingHorizontal: 24, textAlign: 'center' },
});
