import { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import type { Session } from '@supabase/supabase-js';
import type { Profile, Route } from '@ets/shared';
import { supabase } from '../lib/supabase';

interface Props {
  session: Session;
  onSelectRoute: (route: Route) => void;
}

type RouteWithTripStatus = Route & { hasActiveTrip: boolean };

const ROLE_LABEL: Record<Profile['role'], string> = {
  parent: "Your child's routes",
  school: 'Routes serving your school',
  ops: 'All ETS routes',
  driver: 'Your routes',
};

export default function HomeScreen({ session, onSelectRoute }: Props) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [routes, setRoutes] = useState<RouteWithTripStatus[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    const { data: profileRow } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .single();
    setProfile(profileRow ?? null);

    // RLS on `routes` already scopes this to what the signed-in role may see
    // (parent -> their child's routes, school -> their school, ops -> all).
    const { data: routeRows } = await supabase
      .from('routes')
      .select('*')
      .eq('active', true)
      .order('name');

    if (!routeRows) {
      setRoutes([]);
      return;
    }

    const { data: activeTrips } = await supabase
      .from('trips')
      .select('route_id')
      .eq('status', 'in_progress')
      .in('route_id', routeRows.map((r) => r.id));

    const activeRouteIds = new Set((activeTrips ?? []).map((t) => t.route_id));
    setRoutes(routeRows.map((r) => ({ ...r, hasActiveTrip: activeRouteIds.has(r.id) })));
  }, [session.user.id]);

  useEffect(() => {
    setLoading(true);
    load().finally(() => setLoading(false));
  }, [load]);

  async function handleRefresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  async function handleSignOut() {
    await supabase.auth.signOut();
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{profile ? ROLE_LABEL[profile.role] : 'Routes'}</Text>
        <TouchableOpacity onPress={handleSignOut}>
          <Text style={styles.signOut}>Sign out</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={routes}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
        ListEmptyComponent={<Text style={styles.empty}>No routes to show yet.</Text>}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.routeRow}
            onPress={() => onSelectRoute(item)}
            disabled={!item.hasActiveTrip}
          >
            <View>
              <Text style={styles.routeName}>{item.name}</Text>
              <Text style={styles.routeDirection}>
                {item.direction === 'pickup' ? 'Pickup' : 'Drop-off'}
              </Text>
            </View>
            <Text style={item.hasActiveTrip ? styles.liveBadge : styles.idleBadge}>
              {item.hasActiveTrip ? 'Live' : 'Not on route'}
            </Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 40,
  },
  title: { fontSize: 20, fontWeight: '700' },
  signOut: { color: '#666', fontSize: 14 },
  empty: { textAlign: 'center', color: '#888', marginTop: 40 },
  routeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  routeName: { fontSize: 16, fontWeight: '600' },
  routeDirection: { fontSize: 13, color: '#888', marginTop: 2 },
  liveBadge: {
    color: '#16a34a',
    fontWeight: '700',
    fontSize: 13,
    backgroundColor: '#dcfce7',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    overflow: 'hidden',
  },
  idleBadge: { color: '#999', fontSize: 13 },
});
