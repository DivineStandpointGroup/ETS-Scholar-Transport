import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import { supabase } from './supabase';

export const LOCATION_TASK_NAME = 'ets-driver-location-report';

// Registered once at module load. expo-task-manager requires this to be a
// top-level call, not inside a component, so the OS can revive the task
// after the app is backgrounded or killed.
TaskManager.defineTask(LOCATION_TASK_NAME, async ({ data, error }) => {
  if (error) {
    console.error('[backgroundLocation] task error', error);
    return;
  }
  const { locations } = (data ?? {}) as { locations?: Location.LocationObject[] };
  if (!locations?.length) return;

  const tripId = await getActiveTripId();
  if (!tripId) return; // no route in progress — drop the ping

  const rows = locations.map((loc) => ({
    trip_id: tripId,
    latitude: loc.coords.latitude,
    longitude: loc.coords.longitude,
    heading: loc.coords.heading,
    speed_kmh: loc.coords.speed != null ? loc.coords.speed * 3.6 : null,
    recorded_at: new Date(loc.timestamp).toISOString(),
  }));

  const { error: insertError } = await supabase.from('location_pings').insert(rows);
  if (insertError) {
    console.error('[backgroundLocation] failed to write pings', insertError);
  }
});

// Phase 0/1 keeps the active trip id in a module variable set by
// RouteScreen when a route starts. Phase 1 hardening should persist this
// (e.g. SecureStore) so a killed-and-revived task can recover it.
let activeTripId: string | null = null;

export function setActiveTripId(tripId: string | null) {
  activeTripId = tripId;
}

async function getActiveTripId(): Promise<string | null> {
  return activeTripId;
}

export async function requestLocationPermissions(): Promise<boolean> {
  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') return false;
  const bg = await Location.requestBackgroundPermissionsAsync();
  return bg.status === 'granted';
}

export async function startLocationReporting(): Promise<void> {
  const alreadyStarted = await Location.hasStartedLocationUpdatesAsync(LOCATION_TASK_NAME);
  if (alreadyStarted) return;

  await Location.startLocationUpdatesAsync(LOCATION_TASK_NAME, {
    accuracy: Location.Accuracy.High,
    timeInterval: 10_000, // 10s — good enough for a live map; tune in Phase 2
    distanceInterval: 25, // meters
    showsBackgroundLocationIndicator: true,
    foregroundService: {
      notificationTitle: 'ETS Driver — route in progress',
      notificationBody: 'Reporting your live location while your route is active.',
    },
  });
}

export async function stopLocationReporting(): Promise<void> {
  const started = await Location.hasStartedLocationUpdatesAsync(LOCATION_TASK_NAME);
  if (started) {
    await Location.stopLocationUpdatesAsync(LOCATION_TASK_NAME);
  }
  setActiveTripId(null);
}
