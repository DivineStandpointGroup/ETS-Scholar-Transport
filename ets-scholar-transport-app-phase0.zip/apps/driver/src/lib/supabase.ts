import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createSupabaseClient } from '@ets/shared';

// createSupabaseClient (from @ets/shared) is the one place both apps build
// their client from, so auth + RLS behaviour stays identical across apps.
// AsyncStorage keeps the driver logged in between app launches.
export const supabase = createSupabaseClient(
  process.env.EXPO_PUBLIC_SUPABASE_URL ?? '',
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '',
  AsyncStorage,
);
