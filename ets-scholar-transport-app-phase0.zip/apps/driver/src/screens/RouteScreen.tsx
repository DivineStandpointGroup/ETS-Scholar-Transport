import { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import type { Session } from '@supabase/supabase-js';
import type { Driver, Route } from '@ets/shared';
import { supabase } from '../lib/supabase';
import {
  requestLocationPermissions,
  setActiveTripId,
  startLocationReporting,
  stopLocationReporting,
} from '../lib/backgroundLocation';

interface Props {
  session: Session;
}

type LoadState =
  | { status: 'loading' }
  | { status: 'ready'; driver: Driver; route: Route | null }
  | { status: 'error'; message: string };

export default function RouteScreen({ session }: Props) {
  const [state, setState] = useState<LoadState>({ status: 'loading' });
  const [activeTrip, setActiveTrip] = useState<{ id: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const loadAssignment = useCallback(async () => {
    setState({ status: 'loading' });
    const { data: driver, error: driverError } = await supabase
      .from('drivers')
      .select('*')
      .eq('id', session.user.id)
      .single();

    if (driverError || !driver) {
      setState({ status: 'error', message: driverError?.message ?? 'Driver profile not found.' });
      return;
    }

    const { data: route } = await supabase
      .from('routes')
      .select('*')
      .eq('default_driver_id', session.user.id)
      .eq('active', true)
      .maybeSingle();

    setState({ status: 'ready', driver, route: route ?? null });
  }, [session.user.id]);

  useEffect(() => {
    loadAssignment();
  }, [loadAssignment]);

  async function handleStartRoute() {
    if (state.status !== 'ready' || !state.route) return;
    const vehicleId = state.route.default_vehicle_id ?? state.driver.default_vehicle_id;
    if (!vehicleId) {
      Alert.alert('No vehicle assigned', 'Ask ETS ops to assign a vehicle to this route or driver.');
      return;
    }

    setBusy(true);
    const granted = await requestLocationPermissions();
    if (!granted) {
      setBusy(false);
      Alert.alert(
        'Location permission needed',
        'ETS Driver needs "Always" location access to report your position while on route.',
      );
      return;
    }

    const { data: trip, error } = await supabase
      .from('trips')
      .insert({
        route_id: state.route.id,
        driver_id: session.user.id,
        vehicle_id: vehicleId,
        status: 'in_progress',
      })
      .select()
      .single();

    setBusy(false);
    if (error || !trip) {
      Alert.alert('Could not start route', error?.message ?? 'Unknown error');
      return;
    }

    setActiveTripId(trip.id);
    await startLocationReporting();
    setActiveTrip({ id: trip.id });
  }

  async function handleEndRoute() {
    if (!activeTrip) return;
    setBusy(true);
    await stopLocationReporting();
    const { error } = await supabase
      .from('trips')
      .update({ status: 'completed', ended_at: new Date().toISOString() })
      .eq('id', activeTrip.id);
    setBusy(false);
    if (error) {
      Alert.alert('Could not close out route cleanly', error.message);
    }
    setActiveTrip(null);
  }

  async function handleSignOut() {
    if (activeTrip) {
      Alert.alert('Route in progress', 'End your route before signing out.');
      return;
    }
    await supabase.auth.signOut();
  }

  if (state.status === 'loading') {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
      </View>
    );
  }

  if (state.status === 'error') {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{state.message}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.title}>{state.route ? state.route.name : 'No route assigned'}</Text>
        <Text style={styles.subtitle}>
          {state.route
            ? `${state.route.direction === 'pickup' ? 'Pickup' : 'Drop-off'} route`
            : 'Ask ETS ops to assign you a default route.'}
        </Text>
      </View>

      <View style={styles.statusBadge}>
        <Text style={styles.statusText}>
          {activeTrip ? 'Route in progress — reporting location' : 'Not on route'}
        </Text>
      </View>

      {state.route && (
        <TouchableOpacity
          style={[styles.button, activeTrip ? styles.buttonStop : styles.buttonStart]}
          onPress={activeTrip ? handleEndRoute : handleStartRoute}
          disabled={busy}
        >
          {busy ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.buttonText}>{activeTrip ? 'End Route' : 'Start Route'}</Text>
          )}
        </TouchableOpacity>
      )}

      <TouchableOpacity style={styles.signOut} onPress={handleSignOut}>
        <Text style={styles.signOutText}>Sign out</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, justifyContent: 'space-between', backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: '700', marginTop: 40 },
  subtitle: { fontSize: 15, color: '#666', marginTop: 4 },
  statusBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#f1f5f9',
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginTop: 16,
  },
  statusText: { fontSize: 13, color: '#334155' },
  button: { borderRadius: 8, paddingVertical: 16, alignItems: 'center' },
  buttonStart: { backgroundColor: '#16a34a' },
  buttonStop: { backgroundColor: '#dc2626' },
  buttonText: { color: '#fff', fontSize: 17, fontWeight: '700' },
  signOut: { alignItems: 'center', paddingVertical: 16 },
  signOutText: { color: '#666', fontSize: 14 },
  error: { color: '#dc2626', textAlign: 'center', paddingHorizontal: 24 },
});
