-- ETS Scholar Transport — Phase 0 data model
-- Covers: schools, scholars, parents, drivers, vehicles, routes, live location,
-- driving telemetry/events, and rolling driver scores.
-- Designed for Supabase (Postgres + Row Level Security + Realtime).

-- ============================================================================
-- Extensions
-- ============================================================================
create extension if not exists "uuid-ossp";

-- ============================================================================
-- Roles
-- ============================================================================
-- Every authenticated user (Supabase auth.users) gets exactly one profile row
-- with a role. Role drives what they can see:
--   driver  -> only their own assigned vehicle/route/trips
--   parent  -> only their own children's scholar rows and those scholars' routes
--   school  -> every route serving their school
--   ops     -> everything (ETS staff)
create type user_role as enum ('driver', 'parent', 'school', 'ops');

create table profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  role user_role not null,
  full_name text not null,
  phone text,
  -- set for role = 'school': which school this admin represents
  school_id uuid,
  created_at timestamptz not null default now()
);

-- ============================================================================
-- Core entities
-- ============================================================================
create table schools (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  address text,
  created_at timestamptz not null default now()
);

alter table profiles
  add constraint profiles_school_id_fkey
  foreign key (school_id) references schools (id) on delete set null;

create table vehicles (
  id uuid primary key default uuid_generate_v4(),
  registration_plate text not null unique,
  make_model text,
  capacity int,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table drivers (
  id uuid primary key references profiles (id) on delete cascade,
  license_number text,
  default_vehicle_id uuid references vehicles (id) on delete set null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table parents (
  id uuid primary key references profiles (id) on delete cascade,
  created_at timestamptz not null default now()
);

create table scholars (
  id uuid primary key default uuid_generate_v4(),
  full_name text not null,
  school_id uuid not null references schools (id) on delete restrict,
  grade text,
  created_at timestamptz not null default now()
);

-- A scholar can have more than one parent/guardian account watching them.
create table scholar_parents (
  scholar_id uuid not null references scholars (id) on delete cascade,
  parent_id uuid not null references parents (id) on delete cascade,
  primary key (scholar_id, parent_id)
);

-- ============================================================================
-- Routes
-- ============================================================================
create type route_direction as enum ('pickup', 'dropoff');

create table routes (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  school_id uuid not null references schools (id) on delete restrict,
  direction route_direction not null,
  default_vehicle_id uuid references vehicles (id) on delete set null,
  default_driver_id uuid references drivers (id) on delete set null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Ordered stops along a route (used to compute progress / ETA).
create table route_stops (
  id uuid primary key default uuid_generate_v4(),
  route_id uuid not null references routes (id) on delete cascade,
  sequence int not null,
  label text not null,
  latitude double precision not null,
  longitude double precision not null,
  unique (route_id, sequence)
);

-- Which scholars ride which route (a scholar usually has one pickup + one
-- dropoff route, but the model allows more for flexibility).
create table route_scholars (
  route_id uuid not null references routes (id) on delete cascade,
  scholar_id uuid not null references scholars (id) on delete cascade,
  pickup_stop_id uuid references route_stops (id) on delete set null,
  primary key (route_id, scholar_id)
);

-- ============================================================================
-- Trips (one instance of a driver running a route on a given day)
-- ============================================================================
create type trip_status as enum ('in_progress', 'completed', 'cancelled');

create table trips (
  id uuid primary key default uuid_generate_v4(),
  route_id uuid not null references routes (id) on delete restrict,
  driver_id uuid not null references drivers (id) on delete restrict,
  vehicle_id uuid not null references vehicles (id) on delete restrict,
  status trip_status not null default 'in_progress',
  started_at timestamptz not null default now(),
  ended_at timestamptz
);

-- Live/historical GPS pings from the driver's phone during a trip.
-- High write volume — kept narrow on purpose. Latest ping per trip is what
-- powers the live map view; the full history powers trip playback.
create table location_pings (
  id bigint generated always as identity primary key,
  trip_id uuid not null references trips (id) on delete cascade,
  latitude double precision not null,
  longitude double precision not null,
  heading double precision,
  speed_kmh double precision,
  recorded_at timestamptz not null default now()
);

create index location_pings_trip_recorded_idx
  on location_pings (trip_id, recorded_at desc);

-- ============================================================================
-- Driver performance telemetry (Phase 3, modeled now so Phase 1 can log
-- toward it without a later migration)
-- ============================================================================
create type driving_event_type as enum (
  'harsh_braking',
  'sharp_acceleration',
  'sharp_cornering',
  'speeding',
  'phone_handling'
);

create table driving_events (
  id bigint generated always as identity primary key,
  trip_id uuid not null references trips (id) on delete cascade,
  driver_id uuid not null references drivers (id) on delete restrict,
  event_type driving_event_type not null,
  severity numeric, -- e.g. g-force magnitude or km/h over limit
  latitude double precision,
  longitude double precision,
  recorded_at timestamptz not null default now()
);

create index driving_events_driver_recorded_idx
  on driving_events (driver_id, recorded_at desc);

-- One rolling score row per driver, recomputed as events come in.
create table driver_scores (
  driver_id uuid primary key references drivers (id) on delete cascade,
  score numeric not null default 100,
  total_trips int not null default 0,
  total_events int not null default 0,
  updated_at timestamptz not null default now()
);

-- ============================================================================
-- Row Level Security
-- ============================================================================
alter table profiles enable row level security;
alter table schools enable row level security;
alter table vehicles enable row level security;
alter table drivers enable row level security;
alter table parents enable row level security;
alter table scholars enable row level security;
alter table scholar_parents enable row level security;
alter table routes enable row level security;
alter table route_stops enable row level security;
alter table route_scholars enable row level security;
alter table trips enable row level security;
alter table location_pings enable row level security;
alter table driving_events enable row level security;
alter table driver_scores enable row level security;

-- Helper: current user's role/school, read from their own profile row.
create or replace function current_role() returns user_role
  language sql stable security definer as
  $$ select role from profiles where id = auth.uid() $$;

create or replace function current_school_id() returns uuid
  language sql stable security definer as
  $$ select school_id from profiles where id = auth.uid() $$;

-- profiles: everyone can read their own row; ops can read all.
create policy profiles_self_read on profiles for select
  using (id = auth.uid() or current_role() = 'ops');

-- schools: readable by ops, the school's own admin, and any parent whose
-- child attends (kept simple — schools are not sensitive data).
create policy schools_read on schools for select
  using (true);

-- vehicles: ops full read; drivers can read their assigned vehicle.
create policy vehicles_read on vehicles for select
  using (
    current_role() = 'ops'
    or id in (select default_vehicle_id from drivers where id = auth.uid())
  );

-- drivers: ops full read; a driver can read their own row.
create policy drivers_self_or_ops on drivers for select
  using (current_role() = 'ops' or id = auth.uid());

-- parents: ops full read; a parent can read their own row.
create policy parents_self_or_ops on parents for select
  using (current_role() = 'ops' or id = auth.uid());

-- scholars: ops sees all; school admin sees their school's scholars;
-- parent sees only their linked children.
create policy scholars_scoped_read on scholars for select
  using (
    current_role() = 'ops'
    or (current_role() = 'school' and school_id = current_school_id())
    or (current_role() = 'parent' and id in (
      select scholar_id from scholar_parents where parent_id = auth.uid()
    ))
  );

create policy scholar_parents_scoped_read on scholar_parents for select
  using (
    current_role() = 'ops'
    or parent_id = auth.uid()
  );

-- routes: ops sees all; school sees their school's routes; driver sees
-- routes they're assigned to (default or via a trip); parent sees routes
-- their child rides.
create policy routes_scoped_read on routes for select
  using (
    current_role() = 'ops'
    or (current_role() = 'school' and school_id = current_school_id())
    or (current_role() = 'driver' and default_driver_id = auth.uid())
    or (current_role() = 'parent' and id in (
      select route_id from route_scholars
      where scholar_id in (
        select scholar_id from scholar_parents where parent_id = auth.uid()
      )
    ))
  );

create policy route_stops_follow_route on route_stops for select
  using (
    route_id in (select id from routes) -- routes policy already scopes visibility
  );

create policy route_scholars_scoped_read on route_scholars for select
  using (
    current_role() = 'ops'
    or scholar_id in (
      select scholar_id from scholar_parents where parent_id = auth.uid()
    )
    or route_id in (
      select id from routes
      where (current_role() = 'school' and school_id = current_school_id())
        or (current_role() = 'driver' and default_driver_id = auth.uid())
    )
  );

-- trips: ops sees all; driver sees their own trips; parent/school see
-- trips on routes visible to them.
create policy trips_scoped_read on trips for select
  using (
    current_role() = 'ops'
    or driver_id = auth.uid()
    or route_id in (
      select id from routes
      where (current_role() = 'school' and school_id = current_school_id())
        or (current_role() = 'parent' and id in (
          select route_id from route_scholars
          where scholar_id in (
            select scholar_id from scholar_parents where parent_id = auth.uid()
          )
        ))
    )
  );

create policy trips_driver_write on trips for insert
  with check (driver_id = auth.uid());

create policy trips_driver_update on trips for update
  using (driver_id = auth.uid());

-- location_pings: same visibility as the parent trip; only the assigned
-- driver may insert pings for their own trip.
create policy location_pings_scoped_read on location_pings for select
  using (
    trip_id in (select id from trips) -- trips policy already scopes visibility
  );

create policy location_pings_driver_write on location_pings for insert
  with check (
    trip_id in (select id from trips where driver_id = auth.uid())
  );

-- driving_events: ops and the driver themself; not shown to parents/school
-- (internal performance data).
create policy driving_events_scoped_read on driving_events for select
  using (current_role() = 'ops' or driver_id = auth.uid());

create policy driving_events_driver_write on driving_events for insert
  with check (driver_id = auth.uid());

-- driver_scores: ops and the driver themself.
create policy driver_scores_scoped_read on driver_scores for select
  using (current_role() = 'ops' or driver_id = auth.uid());

-- ============================================================================
-- Realtime
-- ============================================================================
-- Enable realtime replication on the tables the tracking app subscribes to.
alter publication supabase_realtime add table location_pings;
alter publication supabase_realtime add table trips;
