-- Optional sample data for local/dev testing of Phase 0 scaffolding.
-- Run this AFTER 0001_init.sql and after creating matching auth.users
-- accounts (Supabase Auth) for the driver/parent/school/ops profiles below —
-- profiles.id must equal the corresponding auth.users.id.
-- Replace the placeholder UUIDs with the real auth user ids before running.

-- Schools
insert into schools (id, name, address) values
  ('00000000-0000-0000-0000-000000000001', 'Pecanwood College', 'Hartbeespoort, North West'),
  ('00000000-0000-0000-0000-000000000002', 'Sample Primary School', 'Sample address');

-- Vehicles (ETS currently runs 2)
insert into vehicles (id, registration_plate, make_model, capacity) values
  ('00000000-0000-0000-0000-000000000010', 'ETS 001 GP', 'Toyota Quantum', 15),
  ('00000000-0000-0000-0000-000000000011', 'ETS 002 GP', 'Toyota Quantum', 15);

-- Profiles + role rows — REPLACE these ids with real auth.users ids created
-- via Supabase Auth (dashboard or supabase.auth.signUp) before inserting.
-- insert into profiles (id, role, full_name) values
--   ('<driver-auth-uid>', 'driver', 'Sample Driver'),
--   ('<parent-auth-uid>', 'parent', 'Sample Parent'),
--   ('<school-auth-uid>', 'school', 'Pecanwood Admin'),
--   ('<ops-auth-uid>', 'ops', 'ETS Ops');
--
-- update profiles set school_id = '00000000-0000-0000-0000-000000000001'
--   where id = '<school-auth-uid>';
--
-- insert into drivers (id, default_vehicle_id) values
--   ('<driver-auth-uid>', '00000000-0000-0000-0000-000000000010');
--
-- insert into parents (id) values ('<parent-auth-uid>');

-- Scholars
insert into scholars (id, full_name, school_id, grade) values
  ('00000000-0000-0000-0000-000000000020', 'Sample Scholar 1', '00000000-0000-0000-0000-000000000001', 'Grade 5'),
  ('00000000-0000-0000-0000-000000000021', 'Sample Scholar 2', '00000000-0000-0000-0000-000000000001', 'Grade 3');

-- Route + stops (Pecanwood pickup route)
insert into routes (id, name, school_id, direction, default_vehicle_id) values
  ('00000000-0000-0000-0000-000000000030', 'Pecanwood Morning Pickup', '00000000-0000-0000-0000-000000000001', 'pickup', '00000000-0000-0000-0000-000000000010');

insert into route_stops (route_id, sequence, label, latitude, longitude) values
  ('00000000-0000-0000-0000-000000000030', 1, 'Stop 1', -25.7479, 27.8930),
  ('00000000-0000-0000-0000-000000000030', 2, 'Stop 2', -25.7390, 27.9100),
  ('00000000-0000-0000-0000-000000000030', 3, 'Pecanwood College', -25.6890, 27.8940);

insert into route_scholars (route_id, scholar_id) values
  ('00000000-0000-0000-0000-000000000030', '00000000-0000-0000-0000-000000000020'),
  ('00000000-0000-0000-0000-000000000030', '00000000-0000-0000-0000-000000000021');
