import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { Database } from './types';

// Minimal shape of the AsyncStorage-compatible storage adapter supabase-js
// expects, so this package doesn't need to depend on React Native directly.
export interface AuthStorageAdapter {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
}

/**
 * Both apps call this once at startup, passing their Expo public env vars
 * and their platform's AsyncStorage instance:
 *
 *   import AsyncStorage from '@react-native-async-storage/async-storage';
 *   import { createSupabaseClient } from '@ets/shared';
 *
 *   export const supabase = createSupabaseClient(
 *     process.env.EXPO_PUBLIC_SUPABASE_URL!,
 *     process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!,
 *     AsyncStorage,
 *   );
 *
 * The anon key is safe to ship in the app bundle — Row Level Security in
 * supabase/migrations/0001_init.sql is what actually restricts access per
 * role (driver / parent / school / ops), not the key itself.
 */
export function createSupabaseClient(
  url: string,
  anonKey: string,
  storage?: AuthStorageAdapter,
): SupabaseClient<Database> {
  if (!url || !anonKey) {
    throw new Error(
      'Missing Supabase URL or anon key. Set EXPO_PUBLIC_SUPABASE_URL and ' +
        'EXPO_PUBLIC_SUPABASE_ANON_KEY in your .env file (see README.md).',
    );
  }
  return createClient<Database>(url, anonKey, {
    auth: {
      storage,
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: false,
    },
  });
}

export type { SupabaseClient };
