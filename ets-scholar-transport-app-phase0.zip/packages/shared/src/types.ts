// Types mirroring supabase/migrations/0001_init.sql.
// Keep this file in sync with the schema by hand for now; once the project
// is live, generate it instead with:
//   npx supabase gen types typescript --project-id <id> > src/generated.ts

export type UserRole = 'driver' | 'parent' | 'school' | 'ops';

export interface Profile {
  id: string;
  role: UserRole;
  full_name: string;
  phone: string | null;
  school_id: string | null;
  created_at: string;
}

export interface School {
  id: string;
  name: string;
  address: string | null;
  created_at: string;
}

export interface Vehicle {
  id: string;
  registration_plate: string;
  make_model: string | null;
  capacity: number | null;
  active: boolean;
  created_at: string;
}

export interface Driver {
  id: string;
  license_number: string | null;
  default_vehicle_id: string | null;
  active: boolean;
  created_at: string;
}

export interface Parent {
  id: string;
  created_at: string;
}

export interface Scholar {
  id: string;
  full_name: string;
  school_id: string;
  grade: string | null;
  created_at: string;
}

export interface ScholarParent {
  scholar_id: string;
  parent_id: string;
}

export type RouteDirection = 'pickup' | 'dropoff';

export interface Route {
  id: string;
  name: string;
  school_id: string;
  direction: RouteDirection;
  default_vehicle_id: string | null;
  default_driver_id: string | null;
  active: boolean;
  created_at: string;
}

export interface RouteStop {
  id: string;
  route_id: string;
  sequence: number;
  label: string;
  latitude: number;
  longitude: number;
}

export interface RouteScholar {
  route_id: string;
  scholar_id: string;
  pickup_stop_id: string | null;
}

export type TripStatus = 'in_progress' | 'completed' | 'cancelled';

export interface Trip {
  id: string;
  route_id: string;
  driver_id: string;
  vehicle_id: string;
  status: TripStatus;
  started_at: string;
  ended_at: string | null;
}

export interface LocationPing {
  id: number;
  trip_id: string;
  latitude: number;
  longitude: number;
  heading: number | null;
  speed_kmh: number | null;
  recorded_at: string;
}

export type DrivingEventType =
  | 'harsh_braking'
  | 'sharp_acceleration'
  | 'sharp_cornering'
  | 'speeding'
  | 'phone_handling';

export interface DrivingEvent {
  id: number;
  trip_id: string;
  driver_id: string;
  event_type: DrivingEventType;
  severity: number | null;
  latitude: number | null;
  longitude: number | null;
  recorded_at: string;
}

export interface DriverScore {
  driver_id: string;
  score: number;
  total_trips: number;
  total_events: number;
  updated_at: string;
}

// supabase-js's generic Database type wants Row/Insert/Update per table.
// Phase 0 keeps Insert/Update as Partial<Row> (loosely typed but accurate
// on field names/types) rather than hand-writing exact "required on
// insert" shapes for every table — tighten this once the schema settles.
type Table<Row> = {
  Row: Row;
  Insert: Partial<Row>;
  Update: Partial<Row>;
  Relationships: [];
};

export interface Database {
  public: {
    // Deliberately {} rather than Record<string, never>: an index
    // signature here intersects with Tables and collapses every table's
    // type to `never` in postgrest-js's relationship-resolution machinery
    // (used by .insert()/.update()). {} has no index signature, so it
    // doesn't leak into that intersection.
    Views: {};
    Functions: {};
    Tables: {
      profiles: Table<Profile>;
      schools: Table<School>;
      vehicles: Table<Vehicle>;
      drivers: Table<Driver>;
      parents: Table<Parent>;
      scholars: Table<Scholar>;
      scholar_parents: Table<ScholarParent>;
      routes: Table<Route>;
      route_stops: Table<RouteStop>;
      route_scholars: Table<RouteScholar>;
      trips: Table<Trip>;
      location_pings: Table<LocationPing>;
      driving_events: Table<DrivingEvent>;
      driver_scores: Table<DriverScore>;
    };
  };
}
